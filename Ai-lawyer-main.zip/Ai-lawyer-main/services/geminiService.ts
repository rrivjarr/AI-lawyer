import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Language, NdaFormData } from "../types";

// Helper to get client with current key
const getAiClient = () => {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

let chatInstance: Chat | null = null;
let currentChatCountry = "India";

export const sendMessageToAi = async (message: string, language: Language, country: string = "India"): Promise<string> => {
  try {
    const ai = getAiClient();

    // Initialize chat if not exists, or if the country context has changed
    if (!chatInstance || currentChatCountry !== country) {
      chatInstance = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: `You are Nyaya AI, an elite virtual legal assistant specialized in the laws of ${country}. 
Your tone is professional, empathetic, and authoritative yet accessible.
You MUST advise users based on the constitution, penal codes, contract acts, and relevant statutes of ${country}.
When asked, provide practical steps (Next actions).
Always include a brief disclaimer that you are an AI and this is not professional legal counsel.
If the user selects a regional language, reply in that language.`,
        },
      });
      currentChatCountry = country;
    }

    const prompt = `[Language: ${language}] User Query: ${message}`;

    const response: GenerateContentResponse = await chatInstance.sendMessage({
      message: prompt
    });

    return response.text || "I apologize, I could not generate a response.";
  } catch (error) {
    console.error("Chat Error:", error);
    return "Error connecting to the legal database. Please check your connection or API key.";
  }
};

export const analyzeLegalDocument = async (base64Image: string, language: Language): Promise<string> => {
  try {
    const ai = getAiClient();

    // Use Pro model for reasoning about documents
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png', // Assuming PNG/JPEG generic handling
              data: base64Image
            }
          },
          {
            text: `Analyze this legal document image carefully. 
            Language Preference: ${language}.
            1. Summarize the key terms.
            2. Identify 'Red Flags' or dangerous clauses based on Indian Contract Law.
            3. Suggest necessary changes to protect the user's interest.
            4. If it looks like a rent agreement, divorce paper, or NDA, specify the standard protections missing.`
          }
        ]
      }
    });

    return response.text || "Could not analyze the document.";
  } catch (error) {
    console.error("Analysis Error:", error);
    return "Failed to analyze document. Please ensure the image is clear.";
  }
};

export const generateNdaDocument = async (data: NdaFormData, language: Language): Promise<string> => {
  try {
    const ai = getAiClient();
    const prompt = `
      Draft a formal Non-Disclosure Agreement (NDA) compliant with Indian Law (Indian Contract Act, 1872).
      Language: ${language}.
      
      Details:
      - Disclosing Party (Party A): ${data.partyA}
      - Receiving Party (Party B): ${data.partyB}
      - Jurisdiction: ${data.jurisdiction}
      - Duration: ${data.duration}
      - Purpose: ${data.purpose}
      - Type of Confidential Information: ${data.infoType}

      Structure the response in Markdown format with clear headings.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt
    });

    return response.text || "Failed to generate NDA.";
  } catch (error) {
    console.error("Generation Error:", error);
    return "Error generating the document.";
  }
};