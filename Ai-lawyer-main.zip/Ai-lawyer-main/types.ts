export enum AppView {
  CHAT = 'CHAT',
  ANALYZE = 'ANALYZE',
  NOTICE = 'NOTICE',
  GENERATE = 'GENERATE',
  LAWYERS = 'LAWYERS',
  REMINDERS = 'REMINDERS',
  UPDATES = 'UPDATES',
}

export enum Language {
  ENGLISH = 'English',
  HINDI = 'Hindi',
  MARATHI = 'Marathi',
  TAMIL = 'Tamil',
  TELUGU = 'Telugu',
  BENGALI = 'Bengali'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

export interface Lawyer {
  id: string;
  name: string;
  specialization: string;
  experience: string;
  location: string;
  rating: number;
  contact: string;
  verified: boolean;
  image: string;
}

export interface NdaFormData {
  partyA: string;
  partyB: string;
  jurisdiction: string;
  duration: string;
  purpose: string;
  infoType: string;
  includeNonSolicit: boolean;
  includeNonCompete: boolean;
  includeIpOwnership: boolean;
  includePenaltyClause: boolean;
  includeESignPlaceholders: boolean;
}

export interface AnalysisResult {
  text: string;
}