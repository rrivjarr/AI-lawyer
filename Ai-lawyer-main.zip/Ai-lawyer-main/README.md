# Nyaya AI - Your Legal Companion ⚖️

Nyaya AI is an elite virtual legal assistant tailored to provide accessible legal advice, analyze complex documents, and manage legal timelines. Built with a stunning, modern dark-mode aesthetic and powered by Google Gemini, Nyaya AI bridges the gap between common citizens and complex legal systems.

![Nyaya AI Demo Screenshot](https://raw.githubusercontent.com/gau-rhv/Ai-lawyer/main/public/demo.png) *(Add a screenshot here later!)*

## 🚀 Key Features

### 1. 🤖 Global Legal Chatbot (Multi-Jurisdiction)
- Chat with an AI trained on the constitution, penal codes, and contract acts of various countries.
- **Jurisdiction Toggle:** Switch seamlessly between **India 🇮🇳, United States 🇺🇸, United Kingdom 🇬🇧, Canada 🇨🇦, and Australia 🇦🇺** to get localized legal advice.
- Get actionable next steps tailored to your specific situation.

### 2. 🚨 Legal Notice Analyzer
- Upload legal notices, summons, or warnings.
- The AI analyzes the document and provides a **highly simplified, jargon-free summary**.
- Automatically extracts **Key Dates** and adds them directly to your personal calendar.
- Generates a **Draft Reply (PDF)** to download instantly, formatted professionally.
- Recommends specialized lawyers based on the notice's content.

### 3. 📄 Document Analyzer (Green Flags & Red Flags)
- Upload contracts, NDAs, or rental agreements.
- The AI scans for missing clauses, tricky terms, and "Red Flags" that might put you at a disadvantage. 

### 4. 📝 NDA Builder
- Generate standard Non-Disclosure Agreements instantly by filling out a simple form.
- The AI dynamically drafts the agreement structure compliant with contract laws.

### 5. 📅 Reminder Calendar
- A built-in tracking system for hearing dates, reply deadlines, and contract renewals.
- Dates extracted from the Notice Analyzer are automatically synced here.

### 6. 👨‍⚖️ Lawyer Directory
- Find mock profiles of specialized lawyers (Cyber Law, Corporate Law, Civil Disputes).
- Integrated deeply with the Notice Analyzer to recommend the right expert.

### 7. 🗣️ Bilingual Support
- Toggles between English and localized languages (Hindi) to ensure legal accessibility for all.

---

## 🛠️ Tech Stack

- **Frontend:** React 18, Vite, TypeScript
- **Styling:** Tailwind CSS (with arbitrary value customization and glassmorphism)
- **AI Integration:** Google GenAI SDK (`@google/genai`) - Models: Gemini 3 Flash & Pro
- **PDF Generation:** jsPDF
- **Icons & Typography:** Heroicons, Google Fonts (Inter, Playfair Display)

---

## 💻 Getting Started

### Prerequisites
- Node.js (v18+)
- npm or yarn
- A [Google Gemini API Key](https://aistudio.google.com/)

### Installation

1. **Clone the repository:**
   \`\`\`bash
   git clone https://github.com/gau-rhv/Ai-lawyer.git
   cd Ai-lawyer
   \`\`\`

2. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up Environment Variables:**
   Create a \`.env.local\` file in the root directory and add your Gemini API Key:
   \`\`\`env
   VITE_GEMINI_API_KEY=your_api_key_here
   \`\`\`

4. **Start the Development Server:**
   \`\`\`bash
   npm run dev
   \`\`\`

5. Open your browser and navigate to \`http://localhost:5173\`.

---

## 📝 Disclaimer
*Nyaya AI is a demonstration application. The AI can make mistakes. The information provided by this application does not constitute formal legal counsel. Always consult with a certified legal professional before taking legal action.*
