import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage, Language } from '../types';
import { sendMessageToAi } from '../services/geminiService';
import { getTranslation } from '../utils/translations';
import FeedbackSurvey from './FeedbackSurvey';

interface Props {
  language: Language;
}

const LawyerChat: React.FC<Props> = ({ language }) => {
  const t = getTranslation(language);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [country, setCountry] = useState('India');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Reset or update welcome message when language or country changes
  useEffect(() => {
    setMessages([{
      id: 'init_' + Date.now(),
      role: 'model',
      text: `Jurisdiction set to **${country}**. ${t.chat.welcome}`
    }]);
  }, [language, country, t.chat.welcome]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const SUGGESTED_QUESTIONS = [
    "What is the punishment for theft in India?",
    "Explain the process of filing an FIR.",
    "What are my rights if arrested?",
    "How do I register a startup company?"
  ];

  const handleSend = async (text: string = input) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: text
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await sendMessageToAi(userMsg.text, language, country);
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "I encountered an error. Please try again.",
        isError: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const isLatestModelMessage = (id: string) => {
    const modelMessages = messages.filter(m => m.role === 'model');
    return modelMessages.length > 0 && modelMessages[modelMessages.length - 1].id === id && id !== 'init';
  };

  return (
    <div className="flex flex-col h-full relative">
      <div className="flex justify-center pt-4 sticky top-0 z-20">
         <div className="bg-zinc-900/80 backdrop-blur-md rounded-full border border-white/10 px-4 py-2 flex items-center gap-3 shadow-lg">
            <span className="text-zinc-400 text-xs uppercase tracking-wider font-semibold">Jurisdiction:</span>
            <select 
               value={country} 
               onChange={(e) => setCountry(e.target.value)}
               className="bg-transparent text-white text-sm font-medium outline-none cursor-pointer appearance-none md:pr-4 focus:text-rose-400 transition-colors"
            >
               <option value="India" className="bg-zinc-800 text-white">India 🇮🇳</option>
               <option value="United States" className="bg-zinc-800 text-white">United States 🇺🇸</option>
               <option value="United Kingdom" className="bg-zinc-800 text-white">United Kingdom 🇬🇧</option>
               <option value="Canada" className="bg-zinc-800 text-white">Canada 🇨🇦</option>
               <option value="Australia" className="bg-zinc-800 text-white">Australia 🇦🇺</option>
            </select>
         </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-6 md:p-8 pt-2">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} animate-slide-up`}
          >
            <div
              className={`max-w-[85%] md:max-w-[70%] rounded-2xl p-5 shadow-sm ${msg.role === 'user'
                ? 'bg-zinc-800 text-white border border-white/5'
                : 'bg-transparent text-zinc-100'
                } ${msg.isError ? 'border-red-500/50 bg-red-900/10' : ''}`}
            >
              <div className="prose prose-invert prose-sm md:prose-base max-w-none prose-p:leading-relaxed prose-headings:font-serif prose-headings:text-zinc-50 prose-strong:text-white prose-a:text-blue-400">
                <ReactMarkdown>{msg.text}</ReactMarkdown>
              </div>
            </div>
            
            {msg.role === 'model' && isLatestModelMessage(msg.id) && !isLoading && (
              <div className="w-full max-w-[85%] md:max-w-[70%]">
                <FeedbackSurvey className="!mt-4 !p-4 !rounded-2xl bg-zinc-900/40" />
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start animate-pulse">
            <div className="flex items-center gap-2 p-4">
              <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 md:p-6 bg-gradient-to-t from-black via-black/80 to-transparent">
        <div className="relative max-w-4xl mx-auto flex gap-3 items-end p-2 bg-zinc-900/80 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl transition-all focus-within:ring-1 focus-within:ring-white/20 focus-within:bg-zinc-900">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={t.chat.placeholder}
            rows={1}
            className="flex-1 bg-transparent border-none outline-none text-white placeholder-zinc-500 px-4 py-3 resize-none min-h-[48px] max-h-[120px] scrollbar-hide text-sm md:text-base"
          />
          <button
            onClick={() => handleSend(input)}
            disabled={isLoading || !input.trim()}
            className="p-3 bg-white text-black rounded-full hover:bg-zinc-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105 active:scale-95 m-1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
            </svg>
          </button>
        </div>

        {/* Suggested Chips */}
        {messages.length < 2 && (
          <div className="flex flex-wrap gap-2 justify-center mt-4">
            {SUGGESTED_QUESTIONS.map((qs, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(qs)}
                className="text-xs text-zinc-400 bg-white/5 border border-white/5 hover:bg-white/10 hover:border-white/20 px-3 py-1.5 rounded-full transition-all"
              >
                {qs}
              </button>
            ))}
          </div>
        )}

        <div className="text-center mt-2">
          <p className="text-[10px] text-zinc-600">AI can make mistakes. Please verify important information.</p>
        </div>
      </div>
    </div>
  );
};

export default LawyerChat;