import React from 'react';
import { AppView, Language } from '../types';
import { getTranslation } from '../utils/translations';

interface NavProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  language: Language;
}

const Nav: React.FC<NavProps> = ({ currentView, setView, language }) => {
  const t = getTranslation(language);

  const navItems = [
    {
      id: AppView.CHAT, label: t.nav[AppView.CHAT], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 20.25c4.97 0 9-3.694 9-8.25s-4.03-8.25-9-8.25S3 7.444 3 12c0 2.104.859 4.023 2.273 5.48.432.447.74 1.04.586 1.641a4.483 4.483 0 01-.923 1.785A5.969 5.969 0 006 21c1.282 0 2.47-.402 3.445-1.087.81.22 1.668.337 2.555.337z" />
        </svg>
      )
    },
    {
      id: AppView.ANALYZE, label: t.nav[AppView.ANALYZE], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
        </svg>
      )
    },
    {
      id: AppView.NOTICE, label: t.nav[AppView.NOTICE] || 'Legal Notice', icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      )
    },
    {
      id: AppView.GENERATE, label: t.nav[AppView.GENERATE], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 00-3.7-3.7 48.678 48.678 0 00-7.324 0 4.006 4.006 0 00-3.7 3.7c-.017.22-.032.441-.046.662M19.5 12l3-3m-3 3l-3-3m-12 3c0 1.232.046 2.453.138 3.662a4.006 4.006 0 003.7 3.7 48.656 48.656 0 007.324 0 4.006 4.006 0 003.7-3.7c.017-.22.032-.441.046-.662M4.5 12l3 3m-3-3l-3 3" />
        </svg>
      )
    },
    {
      id: AppView.LAWYERS, label: t.nav[AppView.LAWYERS], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
        </svg>
      )
    },
    {
      id: AppView.REMINDERS, label: t.nav[AppView.REMINDERS], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V8.25A2.25 2.25 0 015.25 6h13.5A2.25 2.25 0 0121 8.25v10.5A2.25 2.25 0 0118.75 21H5.25A2.25 2.25 0 013 18.75z" />
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 10.5h18" />
        </svg>
      )
    },
    {
      id: AppView.UPDATES, label: t.nav[AppView.UPDATES], icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-20 md:static md:h-auto md:w-20 lg:w-64 glass md:bg-transparent md:backdrop-filter-none md:border-none md:glass-none z-50 flex-shrink-0 transition-all duration-300">
      <div className="flex md:flex-col justify-around md:justify-start h-full p-2 md:p-0 gap-2 md:gap-4">

        {/* Logo - Desktop Only */}
        <div className="hidden md:flex flex-col items-center lg:items-start lg:px-6 mb-8 mt-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-white to-zinc-400 flex items-center justify-center shadow-lg shadow-white/10 mb-2">
            <span className="text-xl">⚖️</span>
          </div>
          <h1 className="hidden lg:block text-2xl font-serif font-bold text-white tracking-tight">
            Nyaya AI
          </h1>
          <p className="hidden lg:block text-xs text-zinc-500 font-medium tracking-wider uppercase mt-1">Legal Intelligence</p>
        </div>

        {/* Navigation Items */}
        <div className="flex flex-row md:flex-col w-full gap-2 px-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`group flex flex-col lg:flex-row items-center justify-center lg:justify-start p-3 lg:px-6 lg:py-3.5 rounded-2xl transition-all duration-300 relative overflow-hidden ${currentView === item.id
                  ? 'bg-zinc-800 text-white shadow-lg shadow-black/20 ring-1 ring-white/10'
                  : 'text-zinc-500 hover:text-zinc-200 hover:bg-white/5'
                }`}
            >
              {/* Active Indicator Glow */}
              {currentView === item.id && (
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent opacity-50 blur-sm rounded-2xl pointer-events-none"></div>
              )}

              <span className={`relative z-10 transition-transform duration-300 group-hover:scale-110 ${currentView === item.id ? 'scale-110' : ''}`}>
                {item.icon}
              </span>
              <span className={`hidden lg:block ml-4 text-sm font-medium relative z-10 ${currentView === item.id ? 'text-white' : ''}`}>
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Nav;