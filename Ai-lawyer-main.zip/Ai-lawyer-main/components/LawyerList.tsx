import React, { useState } from 'react';
import { Lawyer, Language } from '../types';
import { getTranslation } from '../utils/translations';

const MOCK_LAWYERS: Lawyer[] = [
  {
    id: '1',
    name: 'Adv. Rajesh Verma',
    specialization: 'Criminal Defense & Cyber Law',
    experience: '15 Years',
    location: 'New Delhi High Court',
    rating: 4.9,
    contact: '+91 98XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=1'
  },
  {
    id: '2',
    name: 'Adv. Meera Iyer',
    specialization: 'Family Law & Divorce',
    experience: '12 Years',
    location: 'Mumbai Family Court',
    rating: 4.8,
    contact: '+91 99XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=2'
  },
  {
    id: '3',
    name: 'Adv. Arjun Singh',
    specialization: 'Corporate & Real Estate',
    experience: '20 Years',
    location: 'Bangalore',
    rating: 5.0,
    contact: '+91 97XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=3'
  },
  {
    id: '4',
    name: 'Adv. Kavita Reddy',
    specialization: 'Intellectual Property Rights',
    experience: '8 Years',
    location: 'Hyderabad',
    rating: 4.7,
    contact: '+91 96XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=4'
  },
  {
    id: '5',
    name: 'Adv. Suresh Patel',
    specialization: 'Taxation & Finance',
    experience: '18 Years',
    location: 'Ahmedabad',
    rating: 4.6,
    contact: '+91 95XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=5'
  },
  {
    id: '6',
    name: 'Adv. Anjali Das',
    specialization: 'Labor & Employment',
    experience: '10 Years',
    location: 'Kolkata',
    rating: 4.8,
    contact: '+91 94XXX XXXXX',
    verified: true,
    image: 'https://picsum.photos/200/200?random=6'
  }
];

interface Props {
  language: Language;
  searchQuery?: string;
  setSearchQuery?: (q: string) => void;
}

const LawyerList: React.FC<Props> = ({ language, searchQuery, setSearchQuery }) => {
  const t = getTranslation(language);
  const translations = t.lawyers;

  // Use either the controlled query from props, or an internal one if not provided.
  const [internalSearchTerm, setInternalSearchTerm] = useState('');
  const searchTerm = searchQuery !== undefined ? searchQuery : internalSearchTerm;

  const handleSearchChange = (val: string) => {
    if (setSearchQuery) {
      setSearchQuery(val);
    } else {
      setInternalSearchTerm(val);
    }
  };

  const filteredLawyers = MOCK_LAWYERS.filter(lawyer =>
    lawyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lawyer.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lawyer.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-7xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div>
            <h2 className="text-3xl md:text-4xl font-serif text-white mb-3 tracking-tight">{t.lawyers.title}</h2>
            <p className="text-zinc-400 font-light">{t.lawyers.subtitle}</p>
          </div>
          <div className="w-full md:w-auto relative group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-zinc-500 group-focus-within:text-white transition-colors">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
              </svg>
            </div>
            <input
              type="text"
              placeholder={t.lawyers.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full md:w-80 glass-input pl-12 pr-4 py-3 rounded-full text-white outline-none focus:ring-1 focus:ring-white/20 transition-all bg-white/5 hover:bg-white/10"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
          {filteredLawyers.map((lawyer) => (
            <div key={lawyer.id} className="glass-card rounded-3xl p-6 hover:bg-white/5 transition-all duration-300 group relative overflow-hidden border border-white/5 hover:border-white/10">

              {/* Highlight gradient on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>

              <div className="flex items-start gap-4 mb-6 relative z-10">
                <div className="relative">
                  <img
                    src={lawyer.image}
                    alt={lawyer.name}
                    className="w-16 h-16 rounded-2xl object-cover shadow-lg border border-white/10 group-hover:scale-105 transition-transform duration-500"
                  />
                  {lawyer.verified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-0.5 border-2 border-zinc-900">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                        <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                      </svg>
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-lg text-white leading-tight mb-1 group-hover:text-blue-400 transition-colors">{lawyer.name}</h3>
                  <p className="text-xs text-zinc-400 font-medium tracking-wide uppercase">{lawyer.specialization}</p>
                  <div className="flex items-center gap-1 mt-2 bg-white/5 w-fit px-2 py-0.5 rounded-full">
                    <span className="text-yellow-400 text-xs">★</span>
                    <span className="text-xs text-zinc-200 font-bold">{lawyer.rating}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3 text-sm text-zinc-400 mb-6 bg-black/20 p-4 rounded-xl relative z-10">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium uppercase tracking-wider text-zinc-500">{t.lawyers.experience}</span>
                  <span className="text-zinc-200 font-semibold">{lawyer.experience}</span>
                </div>
                <div className="w-full h-px bg-white/5"></div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium uppercase tracking-wider text-zinc-500">{t.lawyers.location}</span>
                  <span className="text-zinc-200 font-semibold truncate max-w-[120px] text-right">{lawyer.location}</span>
                </div>
              </div>

              <button className="w-full py-3 bg-white text-black rounded-xl font-bold hover:bg-zinc-200 transition-colors relative z-10 transform active:scale-[0.98]">
                {t.lawyers.contact}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LawyerList;