import React, { useState, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { analyzeLegalDocument } from '../services/geminiService';
import { Language } from '../types';
import { getTranslation } from '../utils/translations';
import FeedbackSurvey from './FeedbackSurvey';

const RENTAL_AGREEMENT_HARDCODED_ANALYSIS = `## 🟢 GREEN FLAGS (Good for You as Tenant)

1. ✅ Proper e-Stamp & Registration
- Karnataka non-judicial e-stamp.
- Digitally signed by all parties.
- Legally safer than informal agreements.

2. ✅ Clear Rent & Deposit
- Rent: ₹18,500/month.
- Deposit: ₹70,000 (interest-free, refundable).
- Maintenance clearly mentioned (₹2,500 or actual, whichever higher).

Clarity reduces future disputes.

3. ✅ 1 Month Notice Period (After Lock-In)
- Both landlord and tenant can give 1 month written notice.
- Balanced exit structure (after lock-in).

4. ✅ 6-Month Lock-In (Reasonable)
- 6 months is standard.
- Not excessive like 11–12 months.

5. ✅ Statutory Taxes Paid by Landlord

Clause says:

Property taxes, levies, statutory charges paid by Licensor.

Correct and fair.

6. ✅ Electricity & Water Clearly Assigned
- Tenant pays usage bills.
- No hidden utility ambiguity.

---

## 🔴 RED FLAGS (Important to Watch)

These are the serious ones.

1. 🚩 Major Drafting Error in Duration

Agreement says:
- 23 months (June 15, 2025 – May 15, 2027)

But another clause says:
- “10 months commencing June 15, 2025 to May 15, 2027”

This is legally inconsistent.

If challenged, this can create confusion in court.

👉 This must be corrected.

2. 🚩 “Double Rent Per Day” if You Don’t Vacate

Clause says landlord can:
- Charge double compensation per day
- Remove belongings without court

This is aggressive wording.

In reality, landlord cannot legally evict without due process, but this clause is heavily landlord-favored.

3. 🚩 1 Month Rent Deducted for Painting Automatically

Clause says:

1 month license fee will be deducted from deposit towards painting/cleaning.

This is not conditional.
It sounds automatic.

Even if you maintain property well, they may deduct ₹18,500.

This is a big red flag.

4. 🚩 “No Overnight Stay of Girl or Drinks”

This clause is problematic.
- It restricts personal freedom.
- Legally questionable.
- Hard to enforce but can cause harassment.

This is a social-control clause, not standard legal protection.

5. 🚩 Maintenance: “₹2,500 or Actual, Whichever Higher”

If society increases maintenance, you pay full.
No upper cap.

Risk: maintenance spikes → you absorb cost.

6. 🚩 Vague “Licensor Can Compensate If Asked to Vacate”

One clause says landlord will compensate if asked to vacate.

But:
- No amount mentioned.
- No formula mentioned.

This is vague and weak protection.

7. 🚩 Lock-In Clause – Full Payment for Remaining Period

If you leave during 6-month lock-in:
You must pay rent for entire remaining lock-in period.

Standard — but strict.

8. 🚩 “Remove Without Court”

Clause suggests landlord can remove tenant without court.

In reality:
They legally cannot forcibly evict without procedure.
But this clause shows aggressive drafting mindset.

---

## ⚖ Overall Assessment

- Financial Risk: Medium
- Legal Safety: Moderate (but sloppy drafting)
- Personal Freedom: Restricted
- Deposit Risk: High (due to automatic painting deduction)

---

## 🎯 If You Want to Be Safe

You should ideally:
1. Get the duration clause corrected (23 months consistently).
2. Clarify painting deduction:
- Should only be deducted if repainting required.
3. Remove or soften “no overnight girl/drinks” clause.
4. Ask written cap on maintenance (optional but safer).

---

## 📌 My Straight View

The agreement is:
- Not a scam.
- Not illegal.
- But clearly landlord-tilted.
- Drafted casually with inconsistencies.

Main real risk → Deposit deduction`;

interface Props {
  language: Language;
}

const DocAnalyzer: React.FC<Props> = ({ language }) => {
  const t = getTranslation(language);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isPdf, setIsPdf] = useState(false);
  const [result, setResult] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (selectedFile: File) => {
    setFile(selectedFile);
    setResult('');

    const pdfFile = selectedFile.type === 'application/pdf' || selectedFile.name.toLowerCase().endsWith('.pdf');
    setIsPdf(pdfFile);

    if (pdfFile) {
      setPreview(null);
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);

    try {
      if (isPdf) {
        // const isRentalAgreement = /(rent|rental|lease|licen[cs]e)/i.test(file.name);
        await new Promise((resolve) => setTimeout(resolve, 7000));
        // ALWAYS use mock Rental Agreement Analyzer to save API credits as requested
        setResult(RENTAL_AGREEMENT_HARDCODED_ANALYSIS);
      } else if (preview) {
        await new Promise((resolve) => setTimeout(resolve, 7000));
        // const base64Data = preview.split(',')[1];
        // const analysis = await analyzeLegalDocument(base64Data, language);
        // setResult(analysis);
        // Using mock data for images too to save API credits for the mockup.
        setResult(RENTAL_AGREEMENT_HARDCODED_ANALYSIS);
      }
    } catch (error) {
      setResult("Error analyzing document.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-5xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-serif text-white mb-3 tracking-tight">{t.analyze.title}</h2>
          <p className="text-zinc-400 font-light max-w-2xl">{t.analyze.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 h-full">
          {/* Upload Section */}
          <div className="space-y-6 flex flex-col">
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`
                flex-1 min-h-[300px] border border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 group relative overflow-hidden
                ${preview ? 'border-zinc-700 bg-black/40' : 'border-zinc-700 hover:border-zinc-500 hover:bg-zinc-900/30'}
              `}
            >
              {preview ? (
                <div className="w-full h-full p-6 flex items-center justify-center">
                  <img
                    src={preview}
                    alt="Document Preview"
                    className="max-h-full max-w-full object-contain rounded-lg shadow-2xl"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                    <span className="bg-white text-black px-6 py-2 rounded-full text-sm font-medium transform translate-y-4 group-hover:translate-y-0 transition-transform">
                      Change Image
                    </span>
                  </div>
                </div>
              ) : isPdf && file ? (
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-full bg-zinc-800/50 flex items-center justify-center mb-6 mx-auto border border-white/5">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-zinc-300">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-8.625a3.375 3.375 0 00-3.375-3.375h-8.25A3.375 3.375 0 004.5 5.625v12.75A3.375 3.375 0 007.875 21.75h8.25a3.375 3.375 0 003.375-3.375V14.25z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5h7.5M8.25 11.25h7.5M8.25 15h4.5" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-white mb-2">PDF Uploaded</h3>
                  <p className="text-sm text-zinc-500 break-all">{file.name}</p>
                </div>
              ) : (
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-full bg-zinc-800/50 flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-500 border border-white/5">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-8 h-8 text-zinc-400 group-hover:text-white transition-colors">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-white mb-2">{t.analyze.uploadText}</h3>
                  <p className="text-sm text-zinc-500">{t.analyze.uploadSub}</p>
                </div>
              )}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/png, image/jpeg, image/jpg,application/pdf,.pdf"
                className="hidden"
              />
            </div>

            <button
              onClick={handleAnalyze}
              disabled={!file || loading}
              className="w-full py-4 bg-white text-black font-medium text-lg rounded-2xl shadow-lg hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform active:scale-[0.98]"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                  {t.analyze.analyzing}
                </span>
              ) : t.analyze.button}
            </button>
          </div>

          {/* Results Section */}
          <div className="glass-card rounded-3xl p-8 min-h-[400px] border border-white/5 flex flex-col relative overflow-hidden">
            {/* Decorative gradient */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-[100px] rounded-full pointer-events-none"></div>

            {loading ? (
              <div className="flex flex-col items-center justify-center h-full space-y-6">
                <div className="relative w-8 h-8">
                  <div className="absolute inset-0 border-2 border-zinc-800 rounded-full"></div>
                  <div className="absolute inset-0 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
                <div className="space-y-2 text-center">
                  <p className="text-white font-medium text-sm animate-pulse">{t.analyze.analyzing}</p>
                  <p className="text-sm text-zinc-500">This might take a moment...</p>
                </div>
              </div>
            ) : result ? (
              <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar relative z-10">
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/5">
                  <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-green-400">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                  </div>
                  <h3 className="text-xl text-white font-serif">{t.analyze.reportTitle}</h3>
                </div>
                <div className="prose prose-invert prose-sm max-w-none prose-headings:font-serif prose-p:text-zinc-300">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>
                <FeedbackSurvey className="!mt-12 !bg-zinc-900/40" />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-zinc-600 relative z-10">
                <div className="w-20 h-20 rounded-2xl bg-zinc-900/50 border border-white/5 flex items-center justify-center mb-4 rotate-3">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-10 h-10 opacity-50">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>
                </div>
                <p>Upload a document to see the analysis here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocAnalyzer;