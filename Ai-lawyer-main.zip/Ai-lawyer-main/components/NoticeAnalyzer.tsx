import React, { useState, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { jsPDF } from 'jspdf';
import { Language, AppView } from '../types';
import { getTranslation } from '../utils/translations';
import FeedbackSurvey from './FeedbackSurvey';

const LEGAL_NOTICE_HARDCODED_ANALYSIS = `## 🚨 SERIOUSNESS: HIGH (Money Dispute)

**What is this about?**
This is a legal warning letter sent to Canara Bank by a lawyer. The lawyer is representing a customer named Mr. Ambati Anandpaul. The customer is upset because **Rs. 10,688** was taken out of his bank account on September 23, 2024, without his permission. He says scammers called him asking for his OTP and card details, but he didn't give them anything. Now, he wants the bank to refund his money with interest, claiming the bank didn't keep his money safe.

### 📅 Important Dates:
- **When the money was taken:** September 23, 2024
- **Date on the letter:** April 27, 2024 *(Note: These dates don't match up, which is a mistake in the letter).*
- **When to reply:** As soon as possible (Added to your calendar to remind you).

### ⚖️ What You Need To Do Now:
1. **Check the Account Records:** Look into exactly how the Rs. 10,688 was taken out. Did someone use an OTP? Was it an ATM withdrawal?
2. **See if the Customer Complained Before:** Check if the customer sent any emails or called the bank to report the fraud earlier.
3. **Reply to the Lawyer:** You need to send a formal letter back. If the customer gave away their OTP, tell the lawyer it's not the bank's fault. But if it was a bank system error, you might have to refund them according to RBI rules.
4. **Keep Proof:** Save all records of the transaction and any calls from the customer just in case this goes to court.

### 📝 Draft Reply (Template for the Bank):
*You can copy this template to consult with your legal department.*

> **To: Mannam Sudheer Kumar, Advocate**
>
> **Sub: Reply to Legal Notice Dated 27-04-2024 concerning Account No. 36862200054118**
>
> Under instructions from the Management of Canara Bank, Kakarla Branch, I hereby reply to your legal notice as under:
>
> 1. We acknowledge receipt of your notice regarding your client, Mr. Ambati Anandpaul.
> 2. An internal investigation has been initiated regarding the disputed transaction of Rs. 10,688/- on 23/09/2024.
> 3. Initial logs indicate the transaction was authenticated via [OTP/Secure PIN]. As per RBI guidelines and our terms of service, the bank is not liable for losses where the customer has compromised their credentials to cyber criminals.
> 4. We strongly deny any "Deficiency of Service" or failure to verify records. The debit was an automated clearance of an authenticated transaction.
>
> We advise your client to cooperate with local Cyber Crime authorities, to whom we will provide full assistance. The bank is not liable to pay the claimed damages or interest.
>
> **Yours Sincerely,**
> [Branch Manager/Legal Officer Name]
> Canara Bank

### 👨‍⚖️ Suggested Lawyers for This Case:
Based on the notice, you need a **Corporate & Banking Law Specialist**.
- **Adv. Arjun Singh** (20 Years Exp, Corporate & Real Estate)

*(Check the "Find Lawyer" tab to contact them)*`;

interface Props {
  language: Language;
  setView: (view: AppView) => void;
  setLawyerSearchQuery: (query: string) => void;
}

const NoticeAnalyzer: React.FC<Props> = ({ language, setView, setLawyerSearchQuery }) => {
  const t = getTranslation(language);
  const noticesTranslation = t.notice || {
    title: 'Legal Notice Analyzer',
    subtitle: 'Upload a court summons or legal notice. We will extract key dates, assess severity, and suggest next steps.',
    uploadText: 'Upload Legal Notice (Image/PDF)',
    uploadSub: 'Supports JPG, PNG, PDF',
    button: 'Analyze Notice',
    analyzing: 'Extracting Details...',
    reportTitle: 'Notice Analysis Report',
    emptyState: 'Analysis results will appear here',
  };

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isPdf, setIsPdf] = useState(false);
  const [result, setResult] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (selectedFile: File) => {
    setFile(selectedFile);
    setResult('');

    const pdfFile = selectedFile.type === 'application/pdf' || selectedFile.name.toLowerCase().endsWith('.pdf');
    setIsPdf(pdfFile);

    if (pdfFile) {
      setPreview(null);
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(selectedFile);
  };

  const addMockEventsToCalendar = () => {
    const saved = localStorage.getItem('nyaya_reminders');
    let currentReminders = [];
    if (saved) {
      try {
        currentReminders = JSON.parse(saved);
      } catch (e) {}
    } else {
      currentReminders = [
        { id: '1', title: 'Rent Due', date: '2026-02-05', note: 'Pay rent and save receipt.', priority: 'High' },
        { id: '2', title: 'Utility Bill Check', date: '2026-02-12', note: 'Verify electricity and water bills.', priority: 'Medium' },
        { id: '3', title: 'Notice Window Review', date: '2026-02-20', note: 'Check one-month notice timeline.', priority: 'High' },
        { id: '4', title: 'Deposit Document Audit', date: '2026-02-25', note: 'Keep move-out condition photos ready.', priority: 'Low' },
      ];
    }

    const replyDate = new Date();
    replyDate.setDate(replyDate.getDate() + 3); // Action required within 3 days for urgent banking matters
    const replyDateString = replyDate.toISOString().split('T')[0];

    const newReminders = [...currentReminders];
    if (!newReminders.find((r: any) => r.title === 'Deadline to Reply to Legal Notice (Deficiency)')) {
      newReminders.push({
        id: crypto.randomUUID(),
        title: 'Deadline to Reply to Legal Notice (Deficiency)',
        date: replyDateString,
        note: 'Send formal reply to Adv. Mannam Sudheer Kumar regarding cyber fraud claim.',
        priority: 'High'
      });
    }

    localStorage.setItem('nyaya_reminders', JSON.stringify(newReminders));
    window.dispatchEvent(new Event('remindersUpdated'));
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 7000));
      // ALWAYS use mock Legal Notice Analyzer to save API credits as requested
      setResult(LEGAL_NOTICE_HARDCODED_ANALYSIS);
      addMockEventsToCalendar();
    } catch (error) {
      setResult("Error analyzing document.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    const margins = { top: 25, bottom: 25, left: 25, width: 160 };
    
    // Title Formatting
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("DRAFT REPLY TO LEGAL NOTICE", 105, 35, { align: "center" });
    
    // Body Formatting
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    
    const text = `To: Mannam Sudheer Kumar, Advocate
High Court Advocate & THF Member
Shop No 1, S C S Complex, Opp ABM Degree College, Ongole - A.P.

Sub: Reply to Legal Notice Dated 27-04-2024 concerning Account No. 36862200054118

Under instructions from the Management of Canara Bank, Kakarla Branch, I hereby reply to your legal notice as under:

1. We acknowledge receipt of your notice regarding your client, Mr. Ambati Anandpaul.
2. An internal investigation has been initiated regarding the disputed transaction of Rs. 10,688/- on 23/09/2024.
3. Initial logs indicate the transaction was authenticated securely. As per RBI guidelines and our terms of service, the bank is not liable for losses where the customer has compromised their credentials to cyber criminals.
4. We strongly deny any "Deficiency of Service" or failure to verify records. The debit was an automated clearance of an authenticated transaction.

We advise your client to cooperate with local Cyber Crime authorities, to whom we will provide full assistance. The bank is not liable to pay the claimed damages or interest.

Yours Sincerely,


[Branch Manager/Legal Officer Name]
For Canara Bank`;

    doc.text(text, margins.left, 55, { maxWidth: margins.width, lineHeightFactor: 1.5 });
    
    doc.save('Draft_Reply_Notice.pdf');
  };

  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-5xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-serif text-rose-500 mb-3 tracking-tight">{noticesTranslation.title}</h2>
          <p className="text-zinc-400 font-light max-w-2xl">{noticesTranslation.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 h-full">
          {/* Upload Section */}
          <div className="space-y-6 flex flex-col">
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`
                flex-1 min-h-[300px] border border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 group relative overflow-hidden
                ${preview ? 'border-rose-500/50 bg-rose-900/10' : 'border-zinc-700 hover:border-rose-500/50 hover:bg-rose-900/5'}
              `}
            >
              {preview ? (
                <div className="w-full h-full p-6 flex items-center justify-center">
                  <img
                    src={preview}
                    alt="Document Preview"
                    className="max-h-full max-w-full object-contain rounded-lg shadow-2xl"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                    <span className="bg-white text-black px-6 py-2 rounded-full text-sm font-medium transform translate-y-4 group-hover:translate-y-0 transition-transform">
                      Change Image
                    </span>
                  </div>
                </div>
              ) : isPdf && file ? (
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-full bg-rose-900/20 flex items-center justify-center mb-6 mx-auto border border-rose-500/20">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-rose-400">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-8.625a3.375 3.375 0 00-3.375-3.375h-8.25A3.375 3.375 0 004.5 5.625v12.75A3.375 3.375 0 007.875 21.75h8.25a3.375 3.375 0 003.375-3.375V14.25z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5h7.5M8.25 11.25h7.5M8.25 15h4.5" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-white mb-2">Notice PDF Uploaded</h3>
                  <p className="text-sm text-zinc-500 break-all">{file.name}</p>
                </div>
              ) : (
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-full bg-zinc-800/50 flex items-center justify-center mb-6 mx-auto group-hover:scale-110 transition-transform duration-500 border border-white/5">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-8 h-8 text-rose-400 group-hover:text-rose-300 transition-colors">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-white mb-2">{noticesTranslation.uploadText}</h3>
                  <p className="text-sm text-zinc-500">{noticesTranslation.uploadSub}</p>
                </div>
              )}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/png, image/jpeg, image/jpg,application/pdf,.pdf"
                className="hidden"
              />
            </div>

            <button
              onClick={handleAnalyze}
              disabled={!file || loading}
              className="w-full py-4 bg-rose-600 text-white font-medium text-lg rounded-2xl shadow-lg shadow-rose-900/50 hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform active:scale-[0.98]"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  {noticesTranslation.analyzing}
                </span>
              ) : noticesTranslation.button}
            </button>
          </div>

          {/* Results Section */}
          <div className="glass-card rounded-3xl p-8 min-h-[400px] border border-rose-500/20 bg-rose-900/5 flex flex-col relative overflow-hidden">
            {/* Decorative gradient */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 blur-[100px] rounded-full pointer-events-none"></div>

            {loading ? (
              <div className="flex flex-col items-center justify-center h-full space-y-6">
                <div className="relative w-8 h-8">
                  <div className="absolute inset-0 border-2 border-rose-900 rounded-full"></div>
                  <div className="absolute inset-0 border-2 border-rose-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
                <div className="space-y-2 text-center">
                  <p className="text-rose-400 font-medium text-sm animate-pulse">{noticesTranslation.analyzing}</p>
                  <p className="text-sm text-rose-500/50">Cross-referencing legal statutes...</p>
                </div>
              </div>
            ) : result ? (
              <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar relative z-10">
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-rose-500/20">
                  <div className="w-8 h-8 rounded-full bg-rose-500/20 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-rose-400">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  </div>
                  <h3 className="text-xl text-rose-100 font-serif">{noticesTranslation.reportTitle}</h3>
                </div>
                <div className="prose prose-invert prose-sm max-w-none prose-headings:font-serif prose-p:text-zinc-300">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>

                <div className="mt-8 pt-6 border-t border-rose-500/20 flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => {
                        setLawyerSearchQuery('Arjun Singh');
                        setView(AppView.LAWYERS);
                    }}
                    className="flex-1 bg-rose-600 hover:bg-rose-500 text-white py-3 px-4 rounded-xl font-medium transition-colors shadow-lg shadow-rose-900/40 flex items-center justify-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                    </svg>
                    Contact Adv. Arjun Singh
                  </button>
                  <button 
                    onClick={handleDownloadPDF}
                    className="flex-1 bg-white/10 hover:bg-white/20 text-white py-3 px-4 rounded-xl font-medium transition-colors border border-white/10 flex items-center justify-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
                    </svg>
                    Download Draft Reply (PDF)
                  </button>
                </div>

                <FeedbackSurvey className="!mt-12 !bg-rose-900/20 !border-rose-500/10" />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-zinc-600 relative z-10">
                <div className="w-20 h-20 rounded-2xl bg-rose-900/10 border border-rose-500/10 flex items-center justify-center mb-4 rotate-3">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-10 h-10 opacity-50 text-rose-500">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>
                </div>
                <p>Upload a clear image of the notice here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoticeAnalyzer;
