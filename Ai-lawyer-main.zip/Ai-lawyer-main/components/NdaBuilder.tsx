import React, { useState } from 'react';
import { generateNdaDocument } from '../services/geminiService';
import { Language, NdaFormData } from '../types';
import { getTranslation } from '../utils/translations';
import { generateNdaPdf } from '../utils/ndaPdf';
import FeedbackSurvey from './FeedbackSurvey';

interface Props {
  language: Language;
}

const NdaBuilder: React.FC<Props> = ({ language }) => {
  const t = getTranslation(language);
  const [formData, setFormData] = useState<NdaFormData>({
    partyA: '',
    partyB: '',
    jurisdiction: 'New Delhi, India',
    duration: '2 Years',
    purpose: '',
    infoType: '',
    includeNonSolicit: true,
    includeNonCompete: false,
    includeIpOwnership: true,
    includePenaltyClause: false,
    includeESignPlaceholders: true,
  });
  const [generatedDoc, setGeneratedDoc] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const doc = await generateNdaDocument(formData, language);
      setGeneratedDoc(doc);
    } catch (e) {
      setGeneratedDoc("Error generating document.");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData((prev) => ({ ...prev, [name]: checked }));
  };

  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-6xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-serif text-white mb-3 tracking-tight">{t.nda.title}</h2>
          <p className="text-zinc-400 font-light max-w-2xl">{t.nda.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Form Section */}
          <div className="space-y-6">
            <div className="glass-card p-8 rounded-3xl space-y-6 bg-zinc-900/40 relative overflow-hidden group">
              {/* Subtle gradient effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>

              <div className="flex items-center gap-3 border-b border-white/5 pb-4 mb-2">
                <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 text-indigo-400">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>
                </div>
                <h3 className="text-xl text-white font-medium">{t.nda.detailsTitle}</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.partyA}</label>
                  <input
                    type="text"
                    name="partyA"
                    value={formData.partyA}
                    onChange={handleInputChange}
                    className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none transition-all"
                    placeholder="e.g., Tech Solutions Pvt Ltd"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.partyB}</label>
                  <input
                    type="text"
                    name="partyB"
                    value={formData.partyB}
                    onChange={handleInputChange}
                    className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none transition-all"
                    placeholder="e.g., John Doe"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.jurisdiction}</label>
                  <input
                    type="text"
                    name="jurisdiction"
                    value={formData.jurisdiction}
                    onChange={handleInputChange}
                    className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.duration}</label>
                  <input
                    type="text"
                    name="duration"
                    value={formData.duration}
                    onChange={handleInputChange}
                    className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.purpose}</label>
                <textarea
                  name="purpose"
                  value={formData.purpose}
                  onChange={handleInputChange}
                  className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none min-h-[80px] resize-none transition-all"
                  placeholder="Reason for sharing confidential information..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs text-zinc-400 font-medium uppercase tracking-wider">{t.nda.infoType}</label>
                <textarea
                  name="infoType"
                  value={formData.infoType}
                  onChange={handleInputChange}
                  className="w-full glass-input rounded-xl p-3.5 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none min-h-[80px] resize-none transition-all"
                  placeholder="e.g., Financial Data, Technical Blueprints..."
                />
              </div>

              <div className="space-y-3 border border-white/5 rounded-2xl p-4 bg-black/20">
                <p className="text-xs text-zinc-400 font-medium uppercase tracking-wider">Optional Clauses & Execution</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <label className="flex items-center gap-2 text-sm text-zinc-300">
                    <input type="checkbox" name="includeNonSolicit" checked={formData.includeNonSolicit} onChange={handleCheckboxChange} />
                    Include Non-Solicit clause
                  </label>
                  <label className="flex items-center gap-2 text-sm text-zinc-300">
                    <input type="checkbox" name="includeNonCompete" checked={formData.includeNonCompete} onChange={handleCheckboxChange} />
                    Include Non-Compete clause
                  </label>
                  <label className="flex items-center gap-2 text-sm text-zinc-300">
                    <input type="checkbox" name="includeIpOwnership" checked={formData.includeIpOwnership} onChange={handleCheckboxChange} />
                    Include IP Ownership clause
                  </label>
                  <label className="flex items-center gap-2 text-sm text-zinc-300">
                    <input type="checkbox" name="includePenaltyClause" checked={formData.includePenaltyClause} onChange={handleCheckboxChange} />
                    Include Penalty clause
                  </label>
                  <label className="flex items-center gap-2 text-sm text-zinc-300 md:col-span-2">
                    <input type="checkbox" name="includeESignPlaceholders" checked={formData.includeESignPlaceholders} onChange={handleCheckboxChange} />
                    Add E-sign placeholders & witness lines
                  </label>
                </div>
                <p className="text-[11px] text-zinc-500">These options are applied locally in PDF formatting and do not add extra AI token usage.</p>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-4 bg-white text-black font-bold text-lg rounded-2xl shadow-xl shadow-white/5 hover:bg-zinc-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                  {t.nda.generating}
                </span>
              ) : t.nda.button}
            </button>
          </div>

          {/* Result Section */}
          <div className="glass-card rounded-3xl p-8 min-h-[600px] max-h-[800px] overflow-hidden flex flex-col relative border border-white/5 bg-zinc-900/60 shadow-2xl">
            {/* Decorative blurs */}
            <div className="absolute -top-20 -right-20 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none"></div>
            <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full pointer-events-none"></div>

            {generatedDoc ? (
              <>
                <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/5 relative z-10">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => generateNdaPdf(generatedDoc, formData)}
                      className="text-xs bg-white text-black px-4 py-2 rounded-lg hover:bg-zinc-200 transition-all"
                    >
                      Download PDF
                    </button>
                    <button
                      onClick={() => navigator.clipboard.writeText(generatedDoc)}
                      className="text-xs bg-white/5 text-zinc-300 px-4 py-2 rounded-lg hover:bg-white/10 hover:text-white transition-all border border-white/5"
                    >
                      {t.nda.copy}
                    </button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar relative z-10 pr-2">
                  <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-zinc-300">
                    {generatedDoc}
                  </div>
                  <FeedbackSurvey className="!mt-12 !bg-zinc-900/40" />
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-zinc-600 opacity-60 relative z-10">
                <div className="w-24 h-24 rounded-full bg-zinc-800/30 border border-white/5 flex items-center justify-center mb-6 animate-pulse-slow">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-10 h-10 text-zinc-500">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                  </svg>
                </div>
                <h3 className="text-xl font-medium text-white mb-2">Ready to Draft</h3>
                <p className="text-sm max-w-xs text-center">{t.nda.emptyState}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NdaBuilder;