import React from 'react';

const latestLawNews = [
  {
    id: 'n1',
    title: 'Supreme Court News and Daily Orders',
    source: 'LiveLaw',
    date: 'Updated Daily',
    summary: 'Track day-to-day Supreme Court and High Court developments relevant to litigation and constitutional law.',
    image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=1200&q=80',
    link: 'https://www.livelaw.in/',
  },
  {
    id: 'n2',
    title: 'Legal Industry and Courtroom Coverage',
    source: 'Bar and Bench',
    date: 'Updated Daily',
    summary: 'Follow courtroom stories, appointments, policy updates, and legal profession news in India.',
    image: 'https://images.unsplash.com/photo-1436450412740-6b988f486c6b?auto=format&fit=crop&w=1200&q=80',
    link: 'https://www.barandbench.com/',
  },
  {
    id: 'n3',
    title: 'Indian Bills, Acts and Parliament Trackers',
    source: 'PRS India',
    date: 'Weekly + Session Updates',
    summary: 'Monitor bill summaries, legislative status, and policy research briefs for law and governance topics.',
    image: 'https://images.unsplash.com/photo-1529101091764-c3526daf38fe?auto=format&fit=crop&w=1200&q=80',
    link: 'https://prsindia.org/',
  },
  {
    id: 'n4',
    title: 'Judgments and Statutes Repository',
    source: 'Indian Kanoon',
    date: 'Continuously Updated',
    summary: 'Search judgments, statutes, and citations to stay updated with case law and legal references.',
    image: 'https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&w=1200&q=80',
    link: 'https://indiankanoon.org/',
  },
];

const LegalUpdates: React.FC = () => {
  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-6xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-serif text-white mb-3 tracking-tight">Legal Updates</h2>
          <p className="text-zinc-400 font-light max-w-3xl">Latest law-news sources with direct links for reading updates.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {latestLawNews.map((item) => (
            <article key={item.id} className="glass-card rounded-3xl overflow-hidden border border-white/5">
              <img src={item.image} alt={item.title} className="w-full h-44 object-cover" />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3 gap-3">
                  <span className="text-[11px] px-2 py-1 rounded-full bg-white/10 text-zinc-300">{item.source}</span>
                  <span className="text-xs text-zinc-500">{item.date}</span>
                </div>
                <h3 className="text-lg text-white font-medium mb-2">{item.title}</h3>
                <p className="text-zinc-400 text-sm leading-relaxed mb-4">{item.summary}</p>
                <a
                  href={item.link}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 text-sm px-4 py-2 rounded-lg bg-white text-black hover:bg-zinc-200 transition-all"
                >
                  Open News Source
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LegalUpdates;
