import React, { useMemo, useState } from 'react';

type Reminder = {
  id: string;
  title: string;
  date: string;
  note: string;
  priority: 'Low' | 'Medium' | 'High';
};

const initialReminders: Reminder[] = [
  { id: '1', title: 'Rent Due', date: '2026-02-05', note: 'Pay rent and save receipt.', priority: 'High' },
  { id: '2', title: 'Utility Bill Check', date: '2026-02-12', note: 'Verify electricity and water bills.', priority: 'Medium' },
  { id: '3', title: 'Notice Window Review', date: '2026-02-20', note: 'Check one-month notice timeline.', priority: 'High' },
  { id: '4', title: 'Deposit Document Audit', date: '2026-02-25', note: 'Keep move-out condition photos ready.', priority: 'Low' },
];

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const toDateInputValue = (date: Date) => {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
};

const ReminderCalendar: React.FC = () => {
  const today = new Date();
  const [activeMonth, setActiveMonth] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(toDateInputValue(today));
  
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const saved = localStorage.getItem('nyaya_reminders');
    return saved ? JSON.parse(saved) : initialReminders;
  });

  React.useEffect(() => {
    localStorage.setItem('nyaya_reminders', JSON.stringify(reminders));
  }, [reminders]);

  React.useEffect(() => {
    const handleRemindersUpdate = () => {
      const saved = localStorage.getItem('nyaya_reminders');
      if (saved) {
        setReminders(JSON.parse(saved));
      }
    };
    window.addEventListener('remindersUpdated', handleRemindersUpdate);
    return () => window.removeEventListener('remindersUpdated', handleRemindersUpdate);
  }, []);

  const [newTitle, setNewTitle] = useState('');
  const [newNote, setNewNote] = useState('');
  const [newPriority, setNewPriority] = useState<Reminder['priority']>('Medium');


  const year = activeMonth.getFullYear();
  const monthIndex = activeMonth.getMonth();

  const firstDayIndex = new Date(year, monthIndex, 1).getDay();
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

  const calendarCells = useMemo(() => {
    const cells: Array<{ date: string | null; day: number | null }> = [];
    for (let i = 0; i < firstDayIndex; i += 1) {
      cells.push({ date: null, day: null });
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      const dateStr = `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      cells.push({ date: dateStr, day });
    }
    while (cells.length % 7 !== 0) {
      cells.push({ date: null, day: null });
    }
    return cells;
  }, [daysInMonth, firstDayIndex, monthIndex, year]);

  const remindersByDate = useMemo(() => {
    const map = new Map<string, Reminder[]>();
    reminders.forEach((item) => {
      const existing = map.get(item.date) || [];
      existing.push(item);
      map.set(item.date, existing);
    });
    return map;
  }, [reminders]);

  const selectedDateReminders = remindersByDate.get(selectedDate) || [];

  const goPrevMonth = () => {
    setActiveMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const goNextMonth = () => {
    setActiveMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const addReminder = () => {
    if (!newTitle.trim()) return;
    const newItem: Reminder = {
      id: crypto.randomUUID(),
      title: newTitle.trim(),
      date: selectedDate,
      note: newNote.trim() || 'No notes provided.',
      priority: newPriority,
    };
    setReminders((prev) => [...prev, newItem]);
    setNewTitle('');
    setNewNote('');
    setNewPriority('Medium');
  };

  return (
    <div className="h-full overflow-y-auto p-4 md:p-8">
      <div className="max-w-6xl mx-auto pb-24 md:pb-0">
        <div className="mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-serif text-white mb-3 tracking-tight">Reminder Calendar</h2>
          <p className="text-zinc-400 font-light max-w-3xl">Track rent, notice windows, and legal milestones from one calendar.</p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <section className="xl:col-span-2 glass-card rounded-3xl border border-white/5 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-white/5">
              <button onClick={goPrevMonth} className="w-9 h-9 rounded-full bg-white/5 text-zinc-300 hover:bg-white/10">‹</button>
              <h3 className="text-lg md:text-xl text-white font-serif">{monthNames[monthIndex]} {year}</h3>
              <button onClick={goNextMonth} className="w-9 h-9 rounded-full bg-white/5 text-zinc-300 hover:bg-white/10">›</button>
            </div>

            <div className="grid grid-cols-7 gap-2 p-4">
              {dayNames.map((day) => (
                <div key={day} className="text-center text-xs uppercase tracking-wider text-zinc-500 py-2">{day}</div>
              ))}

              {calendarCells.map((cell, index) => {
                const isSelected = cell.date === selectedDate;
                const dayReminders = cell.date ? remindersByDate.get(cell.date) || [] : [];
                const hasReminder = dayReminders.length > 0;
                return (
                  <button
                    key={`${cell.date || 'empty'}-${index}`}
                    disabled={!cell.date}
                    onClick={() => cell.date && setSelectedDate(cell.date)}
                    className={`h-24 rounded-2xl border transition-all text-left p-2 ${
                      cell.date
                        ? isSelected
                          ? 'border-white/30 bg-white/10'
                          : 'border-white/5 bg-black/20 hover:bg-white/5'
                        : 'border-transparent bg-transparent cursor-default'
                    }`}
                  >
                    {cell.day && (
                      <>
                        <p className="text-sm text-white">{cell.day}</p>
                        {hasReminder && (
                          <div className="mt-1.5 space-y-1">
                            <p className="text-[10px] leading-tight text-zinc-300 truncate rounded-md bg-white/10 px-1.5 py-0.5">
                              {dayReminders[0].title}
                            </p>
                            {dayReminders.length > 1 && (
                              <p className="text-[10px] text-zinc-400">+{dayReminders.length - 1} more</p>
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="glass-card rounded-3xl border border-white/5 p-6 space-y-5">
            <div>
              <h3 className="text-lg text-white font-medium mb-1">Add Reminder</h3>
              <p className="text-xs text-zinc-500">Date: {selectedDate}</p>
            </div>

            <div className="space-y-3">
              <input
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Reminder title"
                className="w-full glass-input rounded-xl p-3 text-white placeholder-zinc-600"
              />
              <textarea
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Notes"
                className="w-full glass-input rounded-xl p-3 text-white placeholder-zinc-600 min-h-[90px] resize-none"
              />
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as Reminder['priority'])}
                className="w-full glass-input rounded-xl p-3 text-white bg-transparent"
              >
                <option value="Low" className="bg-zinc-900">Low</option>
                <option value="Medium" className="bg-zinc-900">Medium</option>
                <option value="High" className="bg-zinc-900">High</option>
              </select>
              <button
                onClick={addReminder}
                className="w-full py-3 bg-white text-black rounded-xl font-medium hover:bg-zinc-200 transition-all"
              >
                Add Data
              </button>
            </div>

            <div className="border-t border-white/5 pt-4">
              <h4 className="text-white text-sm font-medium mb-3">Reminders on {selectedDate}</h4>
              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {selectedDateReminders.length ? (
                  selectedDateReminders.map((item) => (
                    <div key={item.id} className="rounded-xl border border-white/5 bg-black/20 p-3">
                      <div className="flex items-center justify-between gap-3 mb-1">
                        <p className="text-sm text-white">{item.title}</p>
                        <span className="text-[10px] px-2 py-1 rounded-full bg-white/10 text-zinc-300">{item.priority}</span>
                      </div>
                      <p className="text-xs text-zinc-400">{item.note}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-zinc-500">No reminders for this date yet.</p>
                )}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ReminderCalendar;
