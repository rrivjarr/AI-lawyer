import React, { useState } from 'react';

interface FeedbackSurveyProps {
  onFeedbackSubmit?: (feedback: { helpful: boolean; comments: string }) => void;
  className?: string;
}

const FeedbackSurvey: React.FC<FeedbackSurveyProps> = ({ onFeedbackSubmit, className = '' }) => {
  const [helpful, setHelpful] = useState<boolean | null>(null);
  const [comments, setComments] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onFeedbackSubmit) {
      onFeedbackSubmit({ helpful: helpful ?? true, comments });
    }
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className={`mt-6 p-6 rounded-2xl bg-zinc-900/40 border border-white/5 text-center animate-fade-in ${className}`}>
        <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 text-green-400">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
        </div>
        <h4 className="text-white font-medium mb-1">Thank you for your feedback!</h4>
        <p className="text-zinc-500 text-sm">We'll use this to improve our AI responses.</p>
      </div>
    );
  }

  return (
    <div className={`mt-8 p-6 rounded-3xl bg-zinc-900/60 border border-white/5 shadow-xl relative overflow-hidden group ${className}`}>
      {/* Decorative gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
      
      <div className="relative z-10">
        <h4 className="text-lg font-serif text-white mb-4">Help us improve</h4>
        
        <div className="flex flex-col gap-6">
          <div className="space-y-3">
            <p className="text-sm text-zinc-400 font-medium">Was this response helpful?</p>
            <div className="flex gap-3">
              <button
                onClick={() => setHelpful(true)}
                className={`flex-1 py-2.5 rounded-xl border transition-all flex items-center justify-center gap-2 ${
                  helpful === true 
                    ? 'bg-zinc-100 text-black border-zinc-100' 
                    : 'bg-white/5 text-zinc-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.446 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M14.25 9h2.25M5.904 18.75c.083.205.173.405.27.602.197.4-.078.898-.523.898h-.908c-.889 0-1.713-.518-1.972-1.368a12 12 0 01-.521-3.507c0-1.553.295-3.036.831-4.398.306-.742.982-1.277 1.751-1.277h.908c.445 0 .72.498.523.898a8.963 8.963 0 00-.27.602" />
                </svg>
                Yes
              </button>
              <button
                onClick={() => setHelpful(false)}
                className={`flex-1 py-2.5 rounded-xl border transition-all flex items-center justify-center gap-2 ${
                  helpful === false 
                    ? 'bg-zinc-100 text-black border-zinc-100' 
                    : 'bg-white/5 text-zinc-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 15h2.25m8.024-9.75c.011.05.021.1.03.15H19.5c.445 0 .72.498.523.898a8.963 8.963 0 01-.27.602c-.083.205-.173.405-.27.602-.197.4.078.898.523.898h.908c.889 0 1.713.518 1.972 1.368.536 1.362.831 2.845.831 4.398 0 1.553-.295 3.036-.831 4.398-.259.85-1.083 1.368-1.972 1.368h-.908c-.445 0-.72-.498-.523-.898a8.963 8.963 0 01.27-.602c.083-.205.173-.405.27-.602.197-.4-.078-.898-.523-.898h-3.126c-.618 0-.991.724-.725 1.282.463.975.723 2.066.723 3.218 0 .828-.672 1.5-1.5 1.5a.75.75 0 01-.75-.75V21a4.498 4.498 0 00-.322-1.672c-.303-.759-.93-1.331-1.653-1.715a9.04 9.04 0 01-2.861-2.4c-.498-.634-1.225-1.08-2.031-1.08h-2.25m7.5-9h2.25m-7.5 0h-2.25" />
                </svg>
                No
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm text-zinc-400 font-medium">What should we change? / How can we make it better?</label>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Share your thoughts..."
                className="w-full bg-black/20 border border-white/10 rounded-2xl p-4 text-white placeholder-zinc-600 focus:ring-1 focus:ring-white/20 outline-none min-h-[100px] resize-none transition-all"
              />
            </div>
            
            <button
              type="submit"
              disabled={helpful === null && !comments.trim()}
              className="w-full py-3 bg-white text-black font-medium rounded-xl hover:bg-zinc-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-[0.98]"
            >
              Submit Feedback
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default FeedbackSurvey;
