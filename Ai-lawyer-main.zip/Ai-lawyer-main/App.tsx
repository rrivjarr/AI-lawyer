import React, { useState } from 'react';
import Nav from './components/Nav';
import LawyerChat from './components/LawyerChat';
import DocAnalyzer from './components/DocAnalyzer';
import NoticeAnalyzer from './components/NoticeAnalyzer';
import NdaBuilder from './components/NdaBuilder';
import LawyerList from './components/LawyerList';
import ReminderCalendar from './components/ReminderCalendar';
import LegalUpdates from './components/LegalUpdates';
import { AppView, Language } from './types';

function App() {
  const [currentView, setCurrentView] = useState<AppView>(AppView.CHAT);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);

  const [lawyerSearchQuery, setLawyerSearchQuery] = useState('');

  return (
    <div className="relative min-h-screen w-full bg-background text-primary overflow-hidden font-sans selection:bg-white/20">

      {/* 3D Animated Background Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute inset-0 bg-[#09090b]"></div>
        <div className="orb orb-primary w-[600px] h-[600px] top-[-100px] left-[-100px] animate-float opacity-30"></div>
        <div className="orb orb-secondary w-[500px] h-[500px] bottom-[-50px] right-[-50px] animate-pulse-slow opacity-25"></div>
        <div className="orb orb-primary w-[400px] h-[400px] top-[40%] left-[60%] blur-[120px] animate-float opacity-20" style={{ animationDelay: '-2s' }}></div>
      </div>

      {/* Main Layout */}
      <div className="relative z-10 flex flex-col md:flex-row h-screen p-0 md:p-6 gap-6">

        {/* Navigation - Sidebar on Desktop, Bottom/Drawer on Mobile (handled in Nav) */}
        <Nav currentView={currentView} setView={setCurrentView} language={language} />

        {/* Content Area - Floating Glass Card on Desktop */}
        <main className="flex-1 flex flex-col min-w-0 md:rounded-3xl glass-card overflow-hidden transition-all duration-500 border-t border-white/10 md:border md:shadow-2xl">

          {/* Header */}
          <header className="h-16 px-6 flex items-center justify-between border-b border-white/5 bg-white/5 backdrop-blur-md sticky top-0 z-20">
            <div className="md:hidden">
              <span className="text-xl font-serif text-white font-bold tracking-wide">Nyaya AI</span>
            </div>

            <div className="flex-1 flex justify-end items-center gap-4">
              {/* Language Selector */}
              <div className="relative group">
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as Language)}
                  className="appearance-none bg-white/5 border border-white/10 rounded-full py-1.5 pl-4 pr-10 text-xs font-medium text-zinc-300 focus:border-white/30 focus:bg-white/10 outline-none cursor-pointer hover:bg-white/10 transition-all"
                >
                  {Object.values(Language).map((lang) => (
                    <option key={lang} value={lang} className="bg-zinc-900 text-zinc-200">{lang}</option>
                  ))}
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-500">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-3 h-3">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                  </svg>
                </div>
              </div>

              {/* User Profile */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-800 border border-white/10 flex items-center justify-center text-zinc-300 font-bold text-xs shadow-lg hover:scale-105 transition-transform cursor-pointer">
                JD
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-hidden relative bg-black/20">
            <div className={currentView === AppView.CHAT ? "h-full" : "hidden"}><LawyerChat language={language} /></div>
            <div className={currentView === AppView.ANALYZE ? "h-full" : "hidden"}><DocAnalyzer language={language} /></div>
            <div className={currentView === AppView.NOTICE ? "h-full" : "hidden"}><NoticeAnalyzer language={language} setView={setCurrentView} setLawyerSearchQuery={setLawyerSearchQuery} /></div>
            <div className={currentView === AppView.GENERATE ? "h-full" : "hidden"}><NdaBuilder language={language} /></div>
            <div className={currentView === AppView.LAWYERS ? "h-full" : "hidden"}><LawyerList language={language} searchQuery={lawyerSearchQuery} setSearchQuery={setLawyerSearchQuery} /></div>
            <div className={currentView === AppView.REMINDERS ? "h-full flex flex-col" : "hidden"}><ReminderCalendar /></div>
            <div className={currentView === AppView.UPDATES ? "h-full flex flex-col" : "hidden"}><LegalUpdates /></div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;