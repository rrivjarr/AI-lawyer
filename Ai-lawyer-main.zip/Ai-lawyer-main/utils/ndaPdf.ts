import jsPDF from 'jspdf';
import { NdaFormData } from '../types';

const cleanLine = (line: string) =>
  line
    .replace(/^#{1,6}\s*/, '')
    .replace(/^[-*]\s+/, '• ')
    .replace(/^\d+\.\s+/, (match) => match.trim() + ' ')
    .replace(/\*\*/g, '')
    .replace(/`/g, '')
    .trim();

const toPrintableLines = (content: string): string[] =>
  content
    .replace(/```[\s\S]*?```/g, '')
    .split('\n')
    .map(cleanLine)
    .filter((line) => line.length > 0);

const ensurePageSpace = (
  doc: jsPDF,
  currentY: number,
  requiredHeight: number,
  margin: number
): number => {
  const pageHeight = doc.internal.pageSize.getHeight();
  if (currentY + requiredHeight > pageHeight - margin) {
    doc.addPage();
    return margin;
  }
  return currentY;
};

export const generateNdaPdf = (generatedDoc: string, formData: NdaFormData) => {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const margin = 20;
  const pageWidth = doc.internal.pageSize.getWidth();
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  doc.setFont('times', 'bold');
  doc.setFontSize(16);
  doc.text('NON-DISCLOSURE AGREEMENT (NDA)', pageWidth / 2, y, { align: 'center' });
  y += 10;

  doc.setFont('times', 'normal');
  doc.setFontSize(11);
  const introLines = [
    `This Non-Disclosure Agreement is entered into between ${formData.partyA || 'Party A'} (Disclosing Party) and ${formData.partyB || 'Party B'} (Receiving Party).`,
    `Jurisdiction: ${formData.jurisdiction || 'Not specified'}`,
    `Duration: ${formData.duration || 'Not specified'}`,
    `Purpose: ${formData.purpose || 'Not specified'}`,
    `Type of Confidential Information: ${formData.infoType || 'Not specified'}`,
  ];

  const selectedOptionalClauses = [
    formData.includeNonSolicit ? 'Non-Solicit' : null,
    formData.includeNonCompete ? 'Non-Compete' : null,
    formData.includeIpOwnership ? 'IP Ownership' : null,
    formData.includePenaltyClause ? 'Penalty / Liquidated Damages' : null,
  ].filter(Boolean);

  if (selectedOptionalClauses.length) {
    introLines.push(`Selected Optional Clauses: ${selectedOptionalClauses.join(', ')}`);
  }

  introLines.forEach((line) => {
    const wrapped = doc.splitTextToSize(line, contentWidth);
    y = ensurePageSpace(doc, y, wrapped.length * 6, margin);
    doc.text(wrapped, margin, y);
    y += wrapped.length * 6;
  });

  y += 4;
  y = ensurePageSpace(doc, y, 8, margin);
  doc.setFont('times', 'bold');
  doc.text('Terms and Conditions', margin, y);
  y += 7;

  doc.setFont('times', 'normal');
  const bodyLines = toPrintableLines(generatedDoc);
  bodyLines.forEach((line) => {
    const wrapped = doc.splitTextToSize(line, contentWidth);
    y = ensurePageSpace(doc, y, wrapped.length * 6 + 2, margin);
    doc.text(wrapped, margin, y);
    y += wrapped.length * 6 + 1;
  });

  y += 8;
  y = ensurePageSpace(doc, y, 58, margin);
  doc.setFont('times', 'bold');
  doc.text('Signatures', margin, y);
  y += 10;
  doc.setFont('times', 'normal');
  if (formData.includeESignPlaceholders) {
    doc.text(`Disclosing Party (${formData.partyA || 'Party A'}) E-Sign Name: ____________________`, margin, y);
    y += 8;
    doc.text('E-Sign ID / Hash: ____________________', margin, y);
    y += 8;
    doc.text(`Receiving Party (${formData.partyB || 'Party B'}) E-Sign Name: ____________________`, margin, y);
    y += 8;
    doc.text('E-Sign ID / Hash: ____________________', margin, y);
    y += 8;
  } else {
    doc.text(`Disclosing Party (${formData.partyA || 'Party A'}): ____________________`, margin, y);
    y += 10;
    doc.text(`Receiving Party (${formData.partyB || 'Party B'}): ____________________`, margin, y);
    y += 10;
  }

  doc.text('Witness 1 Name & Signature: ____________________', margin, y);
  y += 8;
  doc.text('Witness 2 Name & Signature: ____________________', margin, y);
  y += 8;
  doc.text('Date: ____________________    Place: ____________________', margin, y);

  const pageCount = doc.getNumberOfPages();
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    doc.setPage(pageNumber);
    doc.setFont('times', 'normal');
    doc.setFontSize(9);
    doc.text(`Page ${pageNumber} of ${pageCount}`, pageWidth - margin, doc.internal.pageSize.getHeight() - 10, { align: 'right' });
  }

  const safePartyA = (formData.partyA || 'party-a').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const safePartyB = (formData.partyB || 'party-b').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  doc.save(`nda-${safePartyA}-and-${safePartyB}.pdf`);
};
