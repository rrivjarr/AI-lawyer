import { Language, AppView } from '../types';

export const TRANSLATIONS = {
  [Language.ENGLISH]: {
    nav: {
      [AppView.CHAT]: 'Legal Chat',
      [AppView.ANALYZE]: 'Analyze Doc',
      [AppView.NOTICE]: 'Legal Notice',
      [AppView.GENERATE]: 'NDA Maker',
      [AppView.LAWYERS]: 'Find Lawyer',
      [AppView.REMINDERS]: 'Reminders',
      [AppView.UPDATES]: 'Legal Updates',
    },
    common: {
      loading: 'Loading...',
    },
    chat: {
      placeholder: 'Ask about Indian Law...',
      welcome: 'Namaste! I am Nyaya AI. I can help you understand Indian laws, draft queries, or explain legal concepts.',
      send: 'Send',
    },
    notice: {
      title: 'Legal Notice Analyzer',
      subtitle: 'Upload a court summons or legal notice. We will extract key dates, assess severity, and suggest next steps.',
      uploadText: 'Upload Legal Notice (Image/PDF)',
      uploadSub: 'Supports JPG, PNG, PDF',
      button: 'Analyze Notice',
      analyzing: 'Extracting Details...',
      reportTitle: 'Notice Analysis Report',
      emptyState: 'Analysis results will appear here',
    },
    analyze: {
      title: 'Document Analysis',
      subtitle: 'Upload agreements, contracts, or notices. Our AI will scan for red flags and clauses based on Indian Law.',
      uploadText: 'Click to upload document (Image)',
      uploadSub: 'Supports JPG, PNG',
      button: 'Analyze for Red Flags',
      analyzing: 'Analyzing Risks...',
      reportTitle: 'Legal Analysis Report',
      emptyState: 'Analysis results will appear here',
    },
    nda: {
      title: 'Instant NDA Generator',
      subtitle: 'Generate a Non-Disclosure Agreement tailored for Indian Jurisdiction instantly.',
      detailsTitle: 'Contract Details',
      partyA: 'Disclosing Party (Party A)',
      partyB: 'Receiving Party (Party B)',
      jurisdiction: 'Jurisdiction',
      duration: 'Duration',
      purpose: 'Purpose of Disclosure',
      infoType: 'Type of Confidential Information',
      button: 'Generate Agreement',
      generating: 'Drafting Contract...',
      copy: 'Copy Text',
      emptyState: 'Generated NDA will appear here',
    },
    lawyers: {
      title: 'Verified Lawyers',
      subtitle: 'Connect with top-rated legal professionals for representation.',
      searchPlaceholder: 'Search by specialization or location...',
      verified: 'Verified',
      contact: 'Contact Now',
      experience: 'Experience',
      location: 'Location',
    }
  },
  [Language.HINDI]: {
    nav: {
      [AppView.CHAT]: 'कानूनी चैट',
      [AppView.ANALYZE]: 'दस्तावेज़ विश्लेषण',
      [AppView.NOTICE]: 'कानूनी नोटिस',
      [AppView.GENERATE]: 'NDA निर्माता',
      [AppView.LAWYERS]: 'वकील खोजें',
      [AppView.REMINDERS]: 'रिमाइंडर',
      [AppView.UPDATES]: 'कानूनी अपडेट',
    },
    common: { loading: 'लोड हो रहा है...' },
    chat: {
      placeholder: 'भारतीय कानून के बारे में पूछें...',
      welcome: 'नमस्ते! मैं न्याय एआई हूं। मैं आपको भारतीय कानूनों को समझने में मदद कर सकता हूं।',
      send: 'भेजें',
    },
    analyze: {
      title: 'दस्तावेज़ विश्लेषण',
      subtitle: 'समझौते या अनुबंध अपलोड करें। हमारा एआई भारतीय कानून के आधार पर जांच करेगा।',
      uploadText: 'दस्तावेज़ अपलोड करने के लिए क्लिक करें',
      uploadSub: 'JPG, PNG का समर्थन करता है',
      button: 'विश्लेषण करें',
      analyzing: 'विश्लेषण किया जा रहा है...',
      reportTitle: 'कानूनी विश्लेषण रिपोर्ट',
      emptyState: 'विश्लेषण परिणाम यहां दिखाई देंगे',
    },
    nda: {
      title: 'तत्काल NDA जेनरेटर',
      subtitle: 'भारतीय क्षेत्राधिकार के लिए तुरंत एक गैर-प्रकटीकरण समझौता तैयार करें।',
      detailsTitle: 'अनुबंध विवरण',
      partyA: 'खुलासा करने वाली पार्टी (पार्टी A)',
      partyB: 'प्राप्त करने वाली पार्टी (पार्टी B)',
      jurisdiction: 'क्षेत्राधिकार',
      duration: 'अवधि',
      purpose: 'प्रकटीकरण का उद्देश्य',
      infoType: 'गोपनीय जानकारी का प्रकार',
      button: 'समझौता तैयार करें',
      generating: 'मसौदा तैयार किया जा रहा है...',
      copy: 'कॉपी करें',
      emptyState: 'तैयार किया गया NDA यहां दिखाई देगा',
    },
    lawyers: {
      title: 'सत्यापित वकील',
      subtitle: 'प्रतिनिधित्व के लिए शीर्ष रेटेड कानूनी पेशेवरों से जुड़ें।',
      searchPlaceholder: 'विशेषज्ञता या स्थान से खोजें...',
      verified: 'सत्यापित',
      contact: 'संपर्क करें',
      experience: 'अनुभव',
      location: 'स्थान',
    }
  },
  // Adding defaults/fallbacks for others (mapped to English where localized strings are not yet defined)
  [Language.MARATHI]: {
    nav: {
      [AppView.CHAT]: 'कायदेशीर चॅट',
      [AppView.ANALYZE]: 'कागदपत्र विश्लेषण',
      [AppView.GENERATE]: 'NDA मेकर',
      [AppView.LAWYERS]: 'वकील शोधा',
      [AppView.REMINDERS]: 'रिमाइंडर',
      [AppView.UPDATES]: 'कायदेशीर अपडेट्स',
    },
    common: { loading: 'लोड होत आहे...' },
    chat: {
      placeholder: 'भारतीय कायद्याबद्दल विचारा...',
      welcome: 'नमस्ते! मी न्याय एआय आहे. मी तुम्हाला भारतीय कायदे समजण्यास मदत करू शकतो.',
      send: 'पाठवा',
    },
    analyze: {
      title: 'कागदपत्र विश्लेषण',
      subtitle: 'करार किंवा नोटिसा अपलोड करा. आमचे एआय भारतीय कायद्यानुसार तपास करेल.',
      uploadText: 'अपलोड करण्यासाठी क्लिक करा',
      uploadSub: 'JPG, PNG समर्थित',
      button: 'विश्लेषण करा',
      analyzing: 'विश्लेषण सुरू आहे...',
      reportTitle: 'कायदेशीर विश्लेषण अहवाल',
      emptyState: 'निकाल येथे दिसतील',
    },
    nda: {
      title: 'त्वरित NDA जनरेटर',
      subtitle: 'भारतीय अधिकारक्षेत्रासाठी त्वरित NDA तयार करा.',
      detailsTitle: 'कराराचे तपशील',
      partyA: 'पार्टी A',
      partyB: 'पार्टी B',
      jurisdiction: 'अधिकारक्षेत्र',
      duration: 'कालावधी',
      purpose: 'उद्देश',
      infoType: 'माहितीचा प्रकार',
      button: 'करार तयार करा',
      generating: 'तयार करत आहे...',
      copy: 'कॉपी करा',
      emptyState: 'येथे NDA दिसेल',
    },
    lawyers: {
      title: 'सत्यापित वकील',
      subtitle: 'शीर्ष वकिलांशी संपर्क साधा.',
      searchPlaceholder: 'शोध...',
      verified: 'सत्यापित',
      contact: 'संपर्क',
      experience: 'अनुभव',
      location: 'स्थान',
    }
  }
};

// Fallback for others to English for now, to save space, but keys exist.
[Language.TAMIL, Language.TELUGU, Language.BENGALI].forEach(lang => {
  TRANSLATIONS[lang] = TRANSLATIONS[Language.ENGLISH]; 
});

export const getTranslation = (lang: Language) => TRANSLATIONS[lang] || TRANSLATIONS[Language.ENGLISH];
